package com.java.hib.dao;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.java.hib.Menu;
import com.java.hib.conn.SessionHelper;


@ManagedBean(name="menuMain")
public class MenuMain {
	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	SessionFactory sf;
	
	public Menu[] showMenu() {
		sf=SessionHelper.getConnection();
		Session s=sf.openSession();
		Query q = s.createQuery("from Menu");
		List<Menu>menuList=q.list();
		return menuList.toArray(new Menu[menuList.size()]);
	}
	
	public String addMenu(Menu menu) {
		sf=SessionHelper.getConnection();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.save(menu);
		t.commit();
		return "menuShow.xhtml?faces-redirect=true";
	}
	
public String searchMenu(Menu menu) {
		
		sessionMap.put("m1", menu);  
		return "UpdateMenu.xhtml";
		
	}
	
	public String updateMenu(Menu menu) {
		 sf =SessionHelper.getConnection();
			Session s = sf.openSession();
			Transaction t=s.beginTransaction();
			s.update(menu);
			t.commit();
			return "TabMain.xhtml";
	}
	
	public String deleteMenu(int menuId) {
		 sf =SessionHelper.getConnection();
			Session s = sf.openSession();
			Menu menu= new Menu();
			Query q = s.createQuery("from Menu where MENU_ID="+menuId);
			List<Menu> ulist = q.list();
			if (ulist.size() == 1) {
				 menu = ulist.get(0);
				Transaction t = s.beginTransaction();
			    s.delete(menu);
			    t.commit();
			    System.out.println("Record Deleted...");
			}
			return"Tab.xhtml";
			
		}
}
