package com.java;

public enum Status {
         AVAILABLE,BOOKED
}
